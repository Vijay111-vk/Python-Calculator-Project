
from stack import Stack
from simple_calculator import SimpleCalculator

class AdvancedCalculator(SimpleCalculator):
    def __init__(self):
        self.history = []

    def evaluate_expression(self, input_expression):
        tokens = self.tokenize(input_expression) 
        if not tokens:
            return "Error"
        if not self.check_brackets(tokens):
            return "Error"
        result = self.evaluate_list_tokens(tokens)
        if result == "Error":
            return "Error"
        expression = input_expression.strip()
        self.history.insert(0, (expression, result))
        return result



    def tokenize(self, input_expression):
        tokens = []
        current_token = ""
        for char in input_expression:
            if char.isdigit():
                current_token += char
            elif char in ["+", "-", "*", "/", "(", ")", "{", "}"]:
                if current_token:
                    tokens.append(int(current_token))
                    current_token = ""
                tokens.append(char)
        if current_token:
            tokens.append(int(current_token))
        return tokens

    def check_brackets(self, list_tokens):
        checker=True
        hi=Stack()
        bi=Stack()
        mi=Stack()
        stack = Stack()
        stack.push("Hello")
        l1=[]
        for x in list_tokens:
            if x in ["(",")","{","}"]:
                l1.append(x)
        i=0
        while (i<len(l1) and checker==True):
            if l1[i]=="(":
                mi.push("(")
                hi.push("(")
            elif (hi.is_empty==False) and l1[i]=="{":
                checker="False"
            elif l1[i]=="{":
                mi.push("{")
                bi.push("{")
            else:
                if mi.is_empty():
                    checker=False
                elif l1[i]==")" :
                    hi.pop()
                    mi.pop()
                elif l1[i]=="}" :
                    bi.pop()
                    mi.pop()
            i+=1
        if hi.is_empty() and bi.is_empty() and checker==True and mi.is_empty():
                    return True
        else:
                    return False
        

    def evaluate_list_tokens(self, list_tokens):
        operand_stack = Stack() 
        operator_stack = Stack()
        operator_precedence = {"+": 1, "-": 1, "*": 2, "/": 2}
        for token in list_tokens:
            if isinstance(token, int):
                operand_stack.push(token)
            elif token in ["+", "-", "*", "/"]:
                while (
                    not operator_stack.is_empty()
                    and operator_stack.peek() in ["+", "-", "*", "/"]
                    and operator_precedence[operator_stack.peek()] >= operator_precedence[token]
                ):
                    operator = operator_stack.pop()
                    if operand_stack.is_empty():  
                        return "Error"
                    operand2 = operand_stack.pop()
                    if operand_stack.is_empty():  
                        return "Error"
                    operand1 = operand_stack.pop()
                    result = self.apply_operator(operand1, operator, operand2)
                    if result == "Error":
                        return "Error"
                    operand_stack.push(result)
                operator_stack.push(token)
            elif token in ["(", "{"]:
                operator_stack.push(token)
            elif token in [")", "}"]:
                while not operator_stack.is_empty() and operator_stack.peek() not in ["(", "{"]:
                    operator = operator_stack.pop()
                    if operand_stack.is_empty(): 
                        return "Error"
                    operand2 = operand_stack.pop()
                    if operand_stack.is_empty():  
                        return "Error"
                    operand1 = operand_stack.pop()
                    result = self.apply_operator(operand1, operator, operand2)
                    if result == "Error":
                        return "Error"
                    operand_stack.push(result)
                if not operator_stack.is_empty() and operator_stack.peek() in ["(", "{"]:
                    operator_stack.pop()  
        while not operator_stack.is_empty():
            operator = operator_stack.pop()
            if operand_stack.is_empty(): 
                return "Error"
            operand2 = operand_stack.pop()
            if operand_stack.is_empty():  
                return "Error"
            operand1 = operand_stack.pop()
            result = self.apply_operator(operand1, operator, operand2)
            if result == "Error":
                return "Error"
            operand_stack.push(result)
        return operand_stack.pop()

    def apply_operator(self, operand1, operator, operand2):
        if operator == "+":
            return operand1 + operand2
        elif operator == "-":
            return operand1 - operand2
        elif operator == "*":
            return operand1 * operand2
        elif operator == "/":
            if operand2 == 0:
                return "Error"
            return operand1 / operand2
        

    def get_history(self):
        return self.history
