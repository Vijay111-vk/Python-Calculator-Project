
from stack import Stack

def doeval(a,b,c):
	a = int(a)
	c = int(c)
	if(b== "+"):
		return a+c 
	elif(b== "-"):
		return a-c
	elif(b== "*"):
		return a*c
	elif(b== "/"):
		return a/c
class SimpleCalculator:
	def __init__(self):
		"""
		Instantiate any data attributes
		"""
		self.history = {}
		pass

	def evaluate_expression(self, input_expression):
		"""
		Evaluate the input expression and return the output as a float
		Return a string "Error" if the expression is invalid
		"""
		k = input_expression[:]
		input_expression =input_expression.replace(" ","")
		operator = None
		operatorlist = ["+", "-", "*", "/"]
		ind = None
		for i in range(len(input_expression)):
			if(input_expression[i] in operatorlist):
				operator  = input_expression[i]
				ind = i
				break
		if(operator == None or ind == len(input_expression) - 1 or ind == 0):
			self.history[k] = "Error"
			return "Error"
		a = input_expression[:i]
		b = input_expression[i+1:]
		if(a.isdigit() and b.isdigit()):
			self.history[k] = doeval(a,operator,b)
			return self.history[k]
		self.history[k] = "Error"
		return "Error"

	def get_history(self):
		"""
		Return history of expressions evaluated as a list of (expression, output) tuples
		The order is such that the most recently evaluated expression appears first 
		"""
		l = []
		for i in self.history:
			l.append((i, self.history[i]))  
		return l[::-1]